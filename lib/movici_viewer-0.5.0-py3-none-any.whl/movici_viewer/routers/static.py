from fastapi import APIRouter

static_router = APIRouter(prefix="/")
