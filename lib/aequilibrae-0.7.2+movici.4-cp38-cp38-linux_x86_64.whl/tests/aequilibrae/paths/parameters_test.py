import numpy as np

centroids = np.arange(27) + 1
