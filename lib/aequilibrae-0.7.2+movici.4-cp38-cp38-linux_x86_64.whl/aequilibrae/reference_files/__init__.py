from os.path import dirname, abspath, join

spatialite_database = join(dirname(dirname(abspath(__file__))), "reference_files", "spatialite.sqlite")

# Empty project database with all tables and triggers added
project_database = join(dirname(dirname(abspath(__file__))), "reference_files", "project_database.sqlite")
