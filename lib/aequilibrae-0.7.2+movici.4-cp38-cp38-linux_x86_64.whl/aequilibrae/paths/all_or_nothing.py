import importlib.util as iutil

import numpy as np
from aequilibrae import logger
from aequilibrae.matrix import AequilibraeMatrix

from .multi_threaded_aon import MultiThreadedAoN
from ..utils import WorkerThread

try:
    from aequilibrae.paths.AoN import one_to_all, assign_link_loads
except ImportError as ie:
    logger.warning(f"Could not import procedures from the binary. {ie.args}")

spec = iutil.find_spec("PyQt5")
pyqt = spec is not None
if pyqt:
    from PyQt5.QtCore import pyqtSignal as SIGNAL


class allOrNothing(WorkerThread):
    if pyqt:
        assignment = SIGNAL(object)

    def __init__(self, matrix, graph, results):
        # type: (AequilibraeMatrix, Graph, AssignmentResults)->None

        WorkerThread.__init__(self, None)

        self.matrix = matrix
        self.graph = graph
        self.results = results
        self.aux_res = MultiThreadedAoN()
        self.report = []
        self.cumulative = 0

        if results.__graph_id__ != graph.__id__:
            raise ValueError("Results object not prepared. Use --> results.prepare(graph)")

        elif matrix.matrix_view is None:
            raise ValueError(
                "Matrix was not prepared for assignment. "
                "Please create a matrix_procedures view with all classes you want to assign"
            )

        elif not np.array_equal(matrix.index, graph.centroids):
            raise ValueError("Matrix and graph do not have compatible sets of centroids.")

    def doWork(self):
        self.execute()

    def execute(self):
        if pyqt:
            self.assignment.emit(["zones finalized", 0])

        self.aux_res.prepare(self.graph, self.results)
        self.matrix.matrix_view = self.matrix.matrix_view.reshape(
            (self.graph.num_zones, self.graph.num_zones, self.results.classes["number"])
        )
        mat = self.matrix.matrix_view

        for orig in self.matrix.index:
            i = int(self.graph.nodes_to_indices[orig])
            if self.results.num_skims > 0 or np.nansum(mat[i, :, :]) > 0:
                if self.graph.fs[i] == self.graph.fs[i + 1]:
                    self.report.append("Centroid " + str(orig) + " is not connected")
                else:
                    self.func_assig_thread(orig)

        # TODO: Multi-thread this sum
        self.results.compact_link_loads = np.sum(self.aux_res.temp_link_loads, axis=2)
        assign_link_loads(self.results.link_loads, self.results.compact_link_loads,
                          self.results.crosswalk, self.results.cores)
        if pyqt:
            self.assignment.emit(["finished_threaded_procedure", None])

    def func_assig_thread(self, origin):
        x = one_to_all(origin, self.matrix, self.graph, self.results, self.aux_res, 0)
        self.cumulative += 1
        if x != origin:
            self.report.append(x)
        if pyqt:
            self.assignment.emit(["zones finalized", self.cumulative])
            self.assignment.emit(["text AoN", f"{self.cumulative:,}/{self.graph.num_zones:,}"])
